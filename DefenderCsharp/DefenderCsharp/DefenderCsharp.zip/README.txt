The input file must be located in the directory:
[EXE]/TLB_data/
Where [EXE] is the directory of the .exe file.